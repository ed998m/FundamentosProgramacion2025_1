#ifndef AERODINAMICA_H
#define AERODINAMICA_H

#include "estructura.h"
Resultados calcular_coeficientes(DatosEntrada d);

#endif
