#ifndef ENTRADA_DATOS_H
#define ENTRADA_DATOS_H

#include "estructura.h"

DatosEntrada leer_datos();

#endif
