#ifndef INTERFAZ_H
#define INTERFAZ_H

#include "estructura.h"

void mostrar_estado_terminal(CondicionesISA condiciones, float velocidad, float tiempo);

#endif