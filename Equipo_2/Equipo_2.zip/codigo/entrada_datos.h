#ifndef ENTRADA_DATOS_H
#define ENTRADA_DATOS_H

// Función para que el ususario pueda ingresar datos requeridos
float Ingresar_altura_inicial();

#endif