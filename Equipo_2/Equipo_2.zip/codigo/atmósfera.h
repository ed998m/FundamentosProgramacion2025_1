#ifndef ATMOSFERA_H
#define ATMOSFERA_H

#include "estructura.h"

CondicionesISA Condiciones_ISA(float altitud_m);

#endif