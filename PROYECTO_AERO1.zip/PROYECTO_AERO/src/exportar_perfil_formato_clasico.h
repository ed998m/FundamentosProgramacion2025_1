#ifndef EXPORTAR_PERFIL_CLASICO_H
#define EXPORTAR_PERFIL_CLASICO_H

#include "estructura.h"

void exportar_perfil_clasico(Perfil perfil, const char* codigo_naca);

#endif
