#ifndef NACA_H
#define NACA_H

#include "estructura.h"

Perfil generar_perfil_naca(const char* naca);

#endif
