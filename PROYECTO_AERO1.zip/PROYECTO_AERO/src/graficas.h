#ifndef GRAFICAS_H
#define GRAFICAS_H

#include "estructura.h"

void graficar_perfil(Perfil perfil, const char* naca_code, float cl, float cd);

#endif
